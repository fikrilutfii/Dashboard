<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ActivityLogController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});


use App\Http\Controllers\CustomerBillingReportController;
use App\Http\Controllers\UserAccessController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\FinanceController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\KasbonController;
use App\Http\Controllers\PayrollController;
use App\Http\Controllers\CompanyDebtController;
use App\Http\Controllers\CompanyReceivableController;
use App\Http\Controllers\ExpenseController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::post('/set-division', [App\Http\Controllers\DashboardController::class, 'setDivision'])->name('division.set');
    Route::post('/switch-division', [App\Http\Controllers\DashboardController::class, 'switchDivision'])->name('division.switch');
    Route::get('/dashboard', [App\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');

    Route::get('/user-access', [UserAccessController::class, 'index'])->name('user-access.index');
    Route::put('/user-access/{user}', [UserAccessController::class, 'update'])->name('user-access.update');
    
    // Customer Billing Reports
    Route::get('/reports/billing', [CustomerBillingReportController::class, 'index'])->name('reports.billing');
    Route::get('/reports/billing/{customer}', [CustomerBillingReportController::class, 'show'])->name('reports.billing.show');
    Route::get('/reports/billing/{customer}/print', [CustomerBillingReportController::class, 'print'])->name('reports.billing.print');
    Route::get('/reports/billing/{customer}/export-pdf', [CustomerBillingReportController::class, 'exportPdf'])->name('reports.billing.pdf');
    Route::get('/reports/billing/{customer}/export-excel', [CustomerBillingReportController::class, 'exportExcel'])->name('reports.billing.excel');

    Route::get('/invoices/{invoice}/export', [InvoiceController::class, 'printExcel'])->name('invoices.export');
    Route::resource('invoices', InvoiceController::class);
    
    // Master Data
    Route::resource('customers', CustomerController::class);
    Route::resource('products', ProductController::class);
    Route::resource('suppliers', SupplierController::class);

    // Stock Report (Dashboard) & Adjustment
    Route::get('/reports/stock', [ProductController::class, 'stockReport'])->name('reports.stock');
    Route::post('/products/{product}/adjust-stock', [ProductController::class, 'adjustStock'])->name('products.adjust-stock');

    // API for Product Lookup
    Route::get('/api/products/{code}', [ProductController::class, 'getByCode'])->name('products.lookup');
    Route::post('/products/import-csv', [ProductController::class, 'importCsv'])->name('products.import-csv');

    Route::get('invoices/{invoice}/print', [InvoiceController::class, 'print'])->name('invoices.print');
    Route::get('invoices/{invoice}/print-excel', [InvoiceController::class, 'printExcel'])->name('invoices.print-excel');
    Route::get('invoices/{invoice}/print-combined', [InvoiceController::class, 'printCombined'])->name('invoices.print-combined');
    Route::get('invoices/report/print', [InvoiceController::class, 'printReport'])->name('invoices.printReport');
    Route::put('invoices/{invoice}/status', [InvoiceController::class, 'updateStatus'])->name('invoices.update-status');

    Route::resource('purchases', PurchaseController::class);
    Route::put('purchases/{purchase}/status', [PurchaseController::class, 'updateStatus'])->name('purchases.update-status');
    
    // Expenses
    Route::resource('expenses', ExpenseController::class);

    // Finance
    Route::get('/finance', [App\Http\Controllers\FinanceReportController::class, 'index'])->name('finance.index');
    Route::get('/finance/export/pdf', [App\Http\Controllers\FinanceReportController::class, 'exportPDF'])->name('finance.export.pdf');
    Route::get('/finance/export/excel', [App\Http\Controllers\FinanceReportController::class, 'exportExcel'])->name('finance.export.excel');
    Route::get('/finance/transactions', [FinanceController::class, 'transactions'])->name('finance.transactions');
    Route::post('/finance/transactions', [FinanceController::class, 'storeTransaction'])->name('finance.storeTransaction');
    Route::post('/finance/loan', [FinanceController::class, 'storeLoan'])->name('finance.storeLoan');

    // Hutang & Piutang Perusahaan
    Route::resource('company-debts', CompanyDebtController::class);
    Route::post('/company-debts/{companyDebt}/mark-lunas', [CompanyDebtController::class, 'markLunas'])->name('company-debts.mark-lunas');
    Route::post('/company-debts/{companyDebt}/payment', [CompanyDebtController::class, 'recordPayment'])->name('company-debts.payment');
    
    Route::resource('company-receivables', CompanyReceivableController::class);
    Route::post('/company-receivables/{companyReceivable}/mark-lunas', [CompanyReceivableController::class, 'markLunas'])->name('company-receivables.mark-lunas');
    Route::post('/company-receivables/{companyReceivable}/record-payment', [CompanyReceivableController::class, 'recordPayment'])->name('company-receivables.record-payment');

    // Employees, Absensi & Penggajian (Konfeksi)
    Route::resource('employees', EmployeeController::class);
    Route::post('/kasbons/{kasbon}/repay', [KasbonController::class, 'repay'])->name('kasbons.repay');
    // Kasbons (For Konfeksi/Employees)
    Route::get('/kasbons/print-pdf', [KasbonController::class, 'printPdf'])->name('kasbons.print_pdf');
    Route::resource('kasbons', KasbonController::class)->except(['show']);


    // Penggajian
    Route::get('/payrolls/recap', [PayrollController::class, 'recap'])->name('payrolls.recap');
    Route::post('/payrolls/recap', [PayrollController::class, 'storeRecap'])->name('payrolls.storeRecap');
    Route::get('/payrolls/print', [PayrollController::class, 'print'])->name('payrolls.print');
    Route::get('/payrolls/{payroll}/slip', [PayrollController::class, 'printSlip'])->name('payrolls.slip');
    Route::post('/payrolls/{payroll}/mark-lunas', [PayrollController::class, 'markLunas'])->name('payrolls.mark-lunas');
    Route::resource('payrolls', PayrollController::class)->only(['index', 'create', 'store', 'edit', 'update', 'destroy']);

    // API for Payroll Calculation
    Route::get('/api/employees/{employee}/data', [PayrollController::class, 'getEmployeeData'])->name('api.employees.data');

    // Activity Logs
    Route::get('/activity-logs', [ActivityLogController::class, 'index'])->name('activity-logs.index');
});


Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


require __DIR__.'/auth.php';

Route::get('/run-db-fix', function () {
    try {
        $indexes = Illuminate\Support\Facades\DB::select("SHOW INDEX FROM invoices WHERE Key_name = 'invoices_invoice_number_unique'");
        if (count($indexes) > 0) {
            Illuminate\Support\Facades\Schema::table('invoices', function (Illuminate\Database\Schema\Blueprint $table) {
                $table->dropUnique('invoices_invoice_number_unique');
            });
            echo "Berhasil menghapus aturan unik pada nomor invoice.<br>";
        } else {
            echo "Aturan unik invoice sudah tidak ada.<br>";
        }

        $purchaseIndexes = Illuminate\Support\Facades\DB::select("SHOW INDEX FROM purchases WHERE Key_name = 'purchases_purchase_number_unique'");
        if (count($purchaseIndexes) > 0) {
            Illuminate\Support\Facades\Schema::table('purchases', function (Illuminate\Database\Schema\Blueprint $table) {
                $table->dropUnique('purchases_purchase_number_unique');
            });
            echo "Berhasil menghapus aturan unik pada nomor pembelian.<br>";
        } else {
            echo "Aturan unik pembelian sudah tidak ada.<br>";
        }

        Illuminate\Support\Facades\DB::statement('ALTER TABLE invoices MODIFY invoice_number VARCHAR(255) NULL');
        Illuminate\Support\Facades\DB::statement('ALTER TABLE purchases MODIFY purchase_number VARCHAR(255) NULL');
        echo "Berhasil mengubah kolom invoice_number & purchase_number menjadi nullable.<br>";

        Illuminate\Support\Facades\DB::table('invoices')->where('invoice_number', '')->update(['invoice_number' => null]);
        Illuminate\Support\Facades\DB::table('purchases')->where('purchase_number', '')->update(['purchase_number' => null]);
        echo "Berhasil merapikan data lama.<br>";

        echo "<br><b>Selesai! Halaman ini sudah bisa ditutup.</b>";
    } catch (\Exception $e) {
        echo "Terjadi kesalahan: " . $e->getMessage();
    }
});
