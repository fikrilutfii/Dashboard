<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Purchase;
use App\Models\Transaction;
use App\Models\Payroll;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        
        if (!$request->session()->has('division')) {
            return view('division-selection');
        }

        $division = $request->session()->get('division');

        if ($user->allowed_division !== 'all' && $user->allowed_division !== $division && !($user->allowed_division === 'peternakan' && ($division === 'pemotongan' || $division === 'peternakan'))) {
            $request->session()->forget('division');
            return redirect()->route('dashboard')->with('error', 'Anda tidak memiliki akses ke divisi tersebut.');
        }

        if ($division === 'pemotongan') {
            return redirect()->route('farm.dashboard');
        }

        if ($division === 'peternakan') {
            return redirect()->route('farm.operational.index');
        }

        // Inisialisasi variabel statistik default
        $pembayaranPercetakan = 0;
        $tagihanPercetakan = 0;
        $totalPembayaran = 0;
        $totalTagihan = 0;
        $keuntunganPercetakan = 0;
        $keuntunganKonveksiMingguIni = 0;
        $keuntunganKonveksiBulanIni = 0;

        // Hanya hitung statistik jika bukan limited_invoice
        if ($user->role !== 'limited_invoice') {
            $now = Carbon::now();
            $startOfWeek = Carbon::now()->startOfWeek();

            // --- PEMBAYARAN & TAGIHAN PERCETAKAN ---
            // 1. Pembayaran Percetakan (Bulan Ini) memakai rumus yang sama
            // dengan kartu pembayaran pada menu Pembayaran Perusahaan.
            $pembayaranPercetakan = \App\Models\CompanyDebt::monthlyDueTotal('percetakan', $now);

            // 2. Total Tagihan Percetakan -> sama dengan kartu "Sisa Tagihan"
            // pada menu Tagihan Perusahaan.
            $tagihanPercetakan = \App\Models\CompanyReceivable::where('division', 'percetakan')
                ->whereIn('status', ['belum_lunas', 'sebagian'])
                ->whereNull('kasbon_id')
                ->sum('remaining_amount');

            // 3. Tagihan Percetakan Bulan Ini -> sama dengan kartu
            // "Tagihan Bulan Ini (Angsuran)" pada menu Tagihan Perusahaan.
            $tagihanPercetakanBulanIni = \App\Models\CompanyReceivable::where('division', 'percetakan')
                ->whereIn('status', ['belum_lunas', 'sebagian'])
                ->where('type', 'installment')
                ->whereNull('kasbon_id')
                ->sum('monthly_amount');

            // 3. Total Pembayaran Percetakan (Seluruhnya) -> Company Debt (Sisa Hutang Seluruhnya)
            $totalPembayaran = \App\Models\CompanyDebt::where('division', 'percetakan')
                ->whereIn('status', ['belum_lunas', 'sebagian'])
                ->sum('remaining_amount');

            // 4. Total Tagihan (Bulan Ini) hanya untuk divisi Percetakan.
            $totalTagihan = $tagihanPercetakanBulanIni;

            // --- KEUNTUNGAN (Pemasukan - Pengeluaran) ---
            
            // Pemasukan Percetakan
            $pemasukanPercetakanBulanIni = Transaction::where('type', 'credit')
                ->where('division', 'percetakan')
                ->where('category', '!=', 'kasbon')
                ->whereMonth('date', $now->month)
                ->whereYear('date', $now->year)
                ->sum('amount');

            // 5. Keuntungan Percetakan (Bulan Ini)
            $pengeluaranPercetakanBulanIni = Transaction::where('type', 'debit')
                ->where('division', 'percetakan')
                ->where('category', '!=', 'kasbon')
                ->whereMonth('date', $now->month)
                ->whereYear('date', $now->year)
                ->sum('amount');
            $keuntunganPercetakan = $pemasukanPercetakanBulanIni - $pengeluaranPercetakanBulanIni;

            // 6. Keuntungan Konveksi (Minggu Ini)
            $pemasukanKonveksiMingguIni = Transaction::where('type', 'credit')
                ->where('division', 'konfeksi')
                ->where('category', '!=', 'kasbon')
                ->whereBetween('date', [$startOfWeek, $now])
                ->sum('amount');
            $pengeluaranKonveksiMingguIni = Transaction::where('type', 'debit')
                ->where('division', 'konfeksi')
                ->where('category', '!=', 'kasbon')
                ->whereBetween('date', [$startOfWeek, $now])
                ->sum('amount');
            $keuntunganKonveksiMingguIni = $pemasukanKonveksiMingguIni - $pengeluaranKonveksiMingguIni;

            // 7. Keuntungan Konveksi (Bulan Ini)
            $pemasukanKonveksiBulanIni = Transaction::where('type', 'credit')
                ->where('division', 'konfeksi')
                ->where('category', '!=', 'kasbon')
                ->whereMonth('date', $now->month)
                ->whereYear('date', $now->year)
                ->sum('amount');
            $pengeluaranKonveksiBulanIni = Transaction::where('type', 'debit')
                ->where('division', 'konfeksi')
                ->where('category', '!=', 'kasbon')
                ->whereMonth('date', $now->month)
                ->whereYear('date', $now->year)
                ->sum('amount');
            $keuntunganKonveksiBulanIni = $pemasukanKonveksiBulanIni - $pengeluaranKonveksiBulanIni;
        }

        return view('dashboard', compact(
            'division', 
            'pembayaranPercetakan',
            'tagihanPercetakan',
            'totalPembayaran',
            'totalTagihan',
            'keuntunganPercetakan',
            'keuntunganKonveksiMingguIni',
            'keuntunganKonveksiBulanIni'
        ));
    }

    public function setDivision(Request $request)
    {
        $request->validate([
            'division' => 'required|in:percetakan,konfeksi,pemotongan,peternakan',
        ]);

        $user = $request->user();

        // Access Control
        if ($user->allowed_division !== 'all' && $user->allowed_division !== $request->division && !($user->allowed_division === 'peternakan' && ($request->division === 'pemotongan' || $request->division === 'peternakan'))) {
            return back()->with('error_division', $request->division);
        }

        $request->session()->put('division', $request->division);

        if ($request->division === 'pemotongan') {
            return redirect()->route('farm.dashboard');
        }

        if ($request->division === 'peternakan') {
            return redirect()->route('farm.operational.index');
        }

        return redirect()->route('dashboard');
    }
    public function switchDivision(Request $request)
    {
        $request->session()->forget('division');
        return redirect()->route('dashboard');
    }
}
